module.exports = {
  tokenBot: "7958988523:AAGjTHi4pi9-Gm7YITkcxbtrYpdwWFbp4Co",
  ownerID: "6995090500",
};